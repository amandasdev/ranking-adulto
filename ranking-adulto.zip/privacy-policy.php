<?php include_once('head.php'); ?>

<body class="post-template-default single single-post postid-131 single-format-standard">
	<!-- Google Tag Manager (noscript) -->
	<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-TLJNJR6" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
	<!-- End Google Tag Manager (noscript) -->
	<!-- Google Tag Manager (noscript) -->
	<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-M5D4CMK" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
	<!-- End Google Tag Manager (noscript) -->
	<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
		<defs>
			<filter id="wp-duotone-dark-grayscale">
				<feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " />
				<feComponentTransfer color-interpolation-filters="sRGB">
					<feFuncR type="table" tableValues="0 0.49803921568627" />
					<feFuncG type="table" tableValues="0 0.49803921568627" />
					<feFuncB type="table" tableValues="0 0.49803921568627" />
					<feFuncA type="table" tableValues="1 1" />
				</feComponentTransfer>
				<feComposite in2="SourceGraphic" operator="in" />
			</filter>
		</defs>
	</svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
		<defs>
			<filter id="wp-duotone-grayscale">
				<feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " />
				<feComponentTransfer color-interpolation-filters="sRGB">
					<feFuncR type="table" tableValues="0 1" />
					<feFuncG type="table" tableValues="0 1" />
					<feFuncB type="table" tableValues="0 1" />
					<feFuncA type="table" tableValues="1 1" />
				</feComponentTransfer>
				<feComposite in2="SourceGraphic" operator="in" />
			</filter>
		</defs>
	</svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
		<defs>
			<filter id="wp-duotone-purple-yellow">
				<feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " />
				<feComponentTransfer color-interpolation-filters="sRGB">
					<feFuncR type="table" tableValues="0.54901960784314 0.98823529411765" />
					<feFuncG type="table" tableValues="0 1" />
					<feFuncB type="table" tableValues="0.71764705882353 0.25490196078431" />
					<feFuncA type="table" tableValues="1 1" />
				</feComponentTransfer>
				<feComposite in2="SourceGraphic" operator="in" />
			</filter>
		</defs>
	</svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
		<defs>
			<filter id="wp-duotone-blue-red">
				<feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " />
				<feComponentTransfer color-interpolation-filters="sRGB">
					<feFuncR type="table" tableValues="0 1" />
					<feFuncG type="table" tableValues="0 0.27843137254902" />
					<feFuncB type="table" tableValues="0.5921568627451 0.27843137254902" />
					<feFuncA type="table" tableValues="1 1" />
				</feComponentTransfer>
				<feComposite in2="SourceGraphic" operator="in" />
			</filter>
		</defs>
	</svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
		<defs>
			<filter id="wp-duotone-midnight">
				<feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " />
				<feComponentTransfer color-interpolation-filters="sRGB">
					<feFuncR type="table" tableValues="0 0" />
					<feFuncG type="table" tableValues="0 0.64705882352941" />
					<feFuncB type="table" tableValues="0 1" />
					<feFuncA type="table" tableValues="1 1" />
				</feComponentTransfer>
				<feComposite in2="SourceGraphic" operator="in" />
			</filter>
		</defs>
	</svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
		<defs>
			<filter id="wp-duotone-magenta-yellow">
				<feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " />
				<feComponentTransfer color-interpolation-filters="sRGB">
					<feFuncR type="table" tableValues="0.78039215686275 1" />
					<feFuncG type="table" tableValues="0 0.94901960784314" />
					<feFuncB type="table" tableValues="0.35294117647059 0.47058823529412" />
					<feFuncA type="table" tableValues="1 1" />
				</feComponentTransfer>
				<feComposite in2="SourceGraphic" operator="in" />
			</filter>
		</defs>
	</svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
		<defs>
			<filter id="wp-duotone-purple-green">
				<feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " />
				<feComponentTransfer color-interpolation-filters="sRGB">
					<feFuncR type="table" tableValues="0.65098039215686 0.40392156862745" />
					<feFuncG type="table" tableValues="0 1" />
					<feFuncB type="table" tableValues="0.44705882352941 0.4" />
					<feFuncA type="table" tableValues="1 1" />
				</feComponentTransfer>
				<feComposite in2="SourceGraphic" operator="in" />
			</filter>
		</defs>
	</svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
		<defs>
			<filter id="wp-duotone-blue-orange">
				<feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " />
				<feComponentTransfer color-interpolation-filters="sRGB">
					<feFuncR type="table" tableValues="0.098039215686275 1" />
					<feFuncG type="table" tableValues="0 0.66274509803922" />
					<feFuncB type="table" tableValues="0.84705882352941 0.41960784313725" />
					<feFuncA type="table" tableValues="1 1" />
				</feComponentTransfer>
				<feComposite in2="SourceGraphic" operator="in" />
			</filter>
		</defs>
	</svg>
	<div id="page" class="site">

		<header id="masthead" class="site-header">
			<div class="site-branding">
				<div class="logo">
					<img src="assets/image/total-health-report.png" alt="Total Health Reports" width="415" height="60" />
				</div>
			</div><!-- .site-branding -->

		</header><!-- #masthead -->

		<link rel="stylesheet" type="text/css" href="assets/css/style.privacy-policy.php" />

		<div class="wrapp">

			<div class="main-content-wrap fullwdth">
				<div class="main-content">

					<div class="post-single-wrap">
						<article id="post-131" class="post-131 post type-post status-publish format-standard hentry category-uncategorized">
							<header class="entry-header">
								<h1 class="post-title"><span itemprop="name">Privacy Policy</span></h1>
							</header>

							<div class="entry-content">

								<p>This privacy statement discloses the privacy practices for this website. Totalhealthreports is the sole owner of the information collected on this site. We will not sell, share, or rent this information to others in ways different from what is disclosed in this statement. We will only share or disclose such information in order to conform to the edicts of the law; protect and defend the right or property of our company; or act under exigent circumstances to protect the personal safety of its members or the public. Our company collects information from our users at several different points on our website.</p>
								<h2>Secure ordering online</h2>
								<p>We use technology called Secure Socket Layer (SSL) to encrypt any personal information you transmit to us online. The information is encrypted on your computer and decoded after it reaches our secure server. This information cannot be decrypted during transit.</p>
								<h2>What information we collect and why</h2>
								<p>We collect personal information primarily so that we may process your order, but also so that we may enhance our services to you and make your shopping experience as unique as possible. Our goal is to provide not only the best value on the products we sell, but also the highest level of service possible. In addition to personal information collected for purposes of processing your order, we may ask for the following information: Billing and Shipping Information. During the checkout process, we ask for certain personal information &ndash; name, address, e-mail, telephone number and credit card information &ndash; all of which are necessary for us to process your order and ship it to you. Basic personal information such as name, address and telephone number, but not credit card numbers, may be transmitted to contracted third parties solely for the purpose of shipping your order. As described above, Medmark LLC is safe and secure because we use Secure Socket Layer Technology, which encrypts the information you send to us. This information cannot be decrypted during transmission and decoded on our secure server, which cannot be accessed by 3rd parties.</p>
								<p>Retrieving Information. At any time, you may request from us the information we have collected from you. Simply <a title="contact us" href="contact-us.php">contact us</a>. To protect your privacy, we will only e-mail this information to the e-mail address associated with the particular order and we will NOT e-mail credit card information. We do not give out personal information over the phone.</p>
								<p>&ldquo;<strong>Cookies</strong>&rdquo; are pieces of information that are stored by your Web browser on your computer&rsquo;s hard drive. Our cookies do not contain any personally identifying information, but they do enable us to store items in your shopping cart between visits. Most Web browsers automatically accept cookies, but you can usually change your browser&rsquo;s settings to prevent that. Even without a cookie, you can still use most of the features on this website including placing items in your shopping cart and purchasing them.</p>
								<h2>Notification of Changes</h2>
								<p>If we decide to change our privacy policy, we will post those changes on our Homepage so our users are always aware of what information we collect, how we use it, and under circumstances, if any, we disclose it. If at any point we decide to use personally identifiable information in a manner different from that stated at the time it was collected, we will notify users by way of an email. Users will have a choice as to whether or not we use their information in this different manner. We will use information in accordance with the privacy policy under which the information was collected.</p>
								<p>At Totalhealthreports.com, accessible from https://www.totalhealthreports.com, one of our main priorities is the privacy of our visitors. This Privacy Policy document contains types of information that is collected and recorded by Totalhealthreports.com and how we use it.</p>
								<p>If you have additional questions or require more information about our Privacy Policy, do not hesitate to contact us through the form present on the contact us page.</p>
								<h2>Log Files</h2>
								<p>Totalhealthreports.com follows a standard procedure of using log files. These files log visitors when they visit websites. All hosting companies do this and a part of hosting services&#8217; analytics. The information collected by log files include internet protocol (IP) addresses, browser type, Internet Service Provider (ISP), date and time stamp, referring/exit pages, and possibly the number of clicks. These are not linked to any information that is personally identifiable. The purpose of the information is for analyzing trends, administering the site, tracking users&#8217; movement on the website, and gathering demographic information.</p>
								<h2>Cookies and Web Beacons</h2>
								<p>Like any other website, Totalhealthreports.com uses &#8216;cookies&#8217;. These cookies are used to store information including visitors&#8217; preferences, and the pages on the website that the visitor accessed or visited. The information is used to optimize the users&#8217; experience by customizing our web page content based on visitors&#8217; browser type and/or other information.</p>
								<h2>Google DoubleClick DART Cookie</h2>
								<p>Google is one of a third-party vendor on our site. It also uses cookies, known as DART cookies, to serve ads to our site visitors based upon their visit to www.website.com and other sites on the internet. However, visitors may choose to decline the use of DART cookies by visiting the Google ad and content network Privacy Policy at the following URL &ndash; <a href="#">https://policies.google.com/technologies/ads</a></p>
								<h2>Our Advertising Partners</h2>
								<p>Some of advertisers on our site may use cookies and web beacons. Our advertising partners are listed below. Each of our advertising partners has their own Privacy Policy for their policies on user data. For easier access, we hyperlinked to their Privacy Policies below.</p>
								<ul>
									<li>Google &#8211; <a href="#">https://policies.google.com/technologies/ads</a></li>
								</ul>
								<h2>Privacy Policies</h2>
								<p>You may consult this list to find the Privacy Policy for each of the advertising partners of Totalhealthreports.com.</p>
								<p>Third-party ad servers or ad networks uses technologies like cookies, JavaScript, or Web Beacons that are used in their respective advertisements and links that appear on Totalhealthreports.com, which are sent directly to users&#8217; browser. They automatically receive your IP address when this occurs. These technologies are used to measure the effectiveness of their advertising campaigns and/or to personalize the advertising content that you see on websites that you visit.</p>
								<p>Note that Totalhealthreports.com has no access to or control over these cookies that are used by third-party advertisers.</p>
								<h2>Third Pary Privacy Policies</h2>
								<p>Totalhealthreports.com&#8217;s Privacy Policy does not apply to other advertisers or websites. Thus, we are advising you to consult the respective Privacy Policies of these third-party ad servers for more detailed information. It may include their practices and instructions about how to opt-out of certain options. You may find a complete list of these Privacy Policies and their links here: Privacy Policy Links.</p>
								<p>You can choose to disable cookies through your individual browser options. To know more detailed information about cookie management with specific web browsers, it can be found at the browsers&#8217; respective websites. What Are Cookies?</p>
								<h2>Children&#8217;s Information</h2>
								<p>Another part of our priority is adding protection for children while using the internet. We encourage parents and guardians to observe, participate in, and/or monitor and guide their online activity.</p>
								<p>Totalhealthreports.com does not knowingly collect any Personal Identifiable Information from children under the age of 13. If you think that your child provided this kind of information on our website, we strongly encourage you to contact us immediately and we will do our best efforts to promptly remove such information from our records.</p>
								<h2>Online Privacy Policy Only</h2>
								<p>This privacy policy applies only to our online activities and is valid for visitors to our website with regards to the information that they shared and/or collect in Totalhealthreports.com. This policy is not applicable to any information collected offline or via channels other than this website.</p>
								<h2>Consent</h2>
								<p>By using our website, you hereby consent to our Privacy Policy and agree to its <a href="terms-of-service.php">Terms and Conditions</a>.</p>
							</div>
							<div class="chart-pages">

							</div>

							<div class="clear"></div>

							<div class="clear"></div>

						</article>
					</div>
				</div>
			</div>
			<div class="clear"></div>

			<link rel="stylesheet" type="text/css" href="assets/css/style.privacy-policy.php" />

		</div><!-- .wrap -->

		<?php
		include_once('footer.php');
		?>