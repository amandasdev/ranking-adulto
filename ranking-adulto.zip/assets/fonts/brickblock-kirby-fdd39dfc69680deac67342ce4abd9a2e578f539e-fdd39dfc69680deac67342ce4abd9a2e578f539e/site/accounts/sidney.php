<?php if(!defined('KIRBY')) exit ?>

username: sidney
firstname: Sidney
lastname: Hartwig
email: sidney@brickblock.io
password: >
  $2a$10$tylTSjfkbNE.hQhy2cuVuelDDR3odK6rEbWjzlMqetObJL1Io2MjW
language: en
role: admin
