<a data-shortcut="g" class="nav-icon nav-icon-right" href="#search">
  <?php i('search fa-lg') ?>
</a>

<div class="search dropdown dropdown-right" id="search">
  <form action="<?php _u('search') ?>">
    <input type="text" class="search-input" placeholder="Search…">
    <div class="search-results"></div>
  </form>
</div>