<?php if(!defined('KIRBY')) exit ?>

username: admin
password: >
  $2a$10$vU8CBOzhABU2pQo5mQUWJu28Eio1aCWq7oVLWnSZy0fNmtCr9LFmO
email: paolo@finwerk.com
language: en
role: admin
history:
  - home
  - tokens
  - media
  - roadmap
  - platform
firstname: ""
lastname: ""
