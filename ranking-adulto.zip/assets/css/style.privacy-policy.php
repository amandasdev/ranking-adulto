<style .stickyBtn .stjpgs {
position: relative;
top: 1px;
left: 0;
}

@media screen and (max-width:480px) {
.featured-img {
max-height: 148px
}

.stickyBtn .stjpgs {
width: 67px;
}


     type="text /css">
    .xmas .stickyBtn {
    background: #013475;
    color: #fff;
    max-width: 880px;
    font-size: 22px;
    }

    .xmas .stickyBtn span {
    color: #FFF;
    display: initial;
    }

    .stickyBtn img {
    right: -4px;
    bottom: -2px;
    }

    @media screen and (max-width : 767px) {
    .xmas .stickyBtn span {
    color: #FFF;
    display: block;
    }

    .black-wrap.xmas span {
    display: block;
    font-size: 16px !important;
    }

    .xmas .stickyBtn {
    font-size: 16px;
    line-height: 18px;
    }


    }
    </style>