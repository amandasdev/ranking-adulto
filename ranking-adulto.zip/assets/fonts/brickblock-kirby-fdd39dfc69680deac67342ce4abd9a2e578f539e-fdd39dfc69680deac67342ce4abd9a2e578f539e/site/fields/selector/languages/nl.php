<?php

l::set('selector.empty', 'Nog geen bestanden gevonden.');
l::set('selector.select', 'Selekteer');
